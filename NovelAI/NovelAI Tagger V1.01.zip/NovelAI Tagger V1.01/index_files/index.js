function showimg()
{
    document.getElementById("floating").style.display="block";
}
function hideimg()
{
    document.getElementById("floating").style.display="none";
}
function showhint()
{
    document.getElementById("hint").style.display="block";
}
function closehint()
{
    document.getElementById("hint").style.display="none";
}
function showds()
{
    document.getElementById("ds").style.display="block";
}
function closeds()
{
    document.getElementById("ds").style.display="none";
}
function showjd()
{
    document.getElementById("jd").style.display="block";
}
function closejd()
{
    document.getElementById("jd").style.display="none";
}

function opendoc()
{
    window.open("https://www.kdocs.cn/l/cvg8ccOGj5sq", "_blank"); 
}
function openquest()
{
    window.open("http://jiangnanuniversity.mikecrm.com/bw0ylIm", "_blank"); 
}
